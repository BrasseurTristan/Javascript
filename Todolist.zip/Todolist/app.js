let inputTodo = document.querySelector('#input').value;
const liste = document.querySelector('#list');
const validation = document.querySelector('#validation');
input.addEventListener("keypress", function(event) {
    if (event.key === "Enter") {
      event.preventDefault();
      document.getElementById("validation").click();
      document.querySelector('#input').value = "";
    }
  });

function createDelete () {
    inputTodo = document.querySelector('#input').value;
    liste.insertAdjacentHTML('afterbegin',`<li class="test"> ${inputTodo}</li>`);
    const listed = liste.querySelector('.test')
    listed.addEventListener('dblclick',()=>listed.remove());
    listed.addEventListener('click',()=>{listed.classList.toggle('barre');});
}

validation.addEventListener('click',()=>{createDelete()})