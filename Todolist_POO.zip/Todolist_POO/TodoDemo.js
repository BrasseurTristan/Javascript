"use strict";

// une Todo, information du contenu, barré ou supp
class Todo {
  constructor(text){
    this.text=text;
    this.isChecked = false;
  }
  updateCheck() {
    this.isChecked = !this.isChecked;
  }
}

// une liste de qqch, reutilisable pour nimporte quel qqch, stockage des taches dans list
class List {
  #list = [];
  #Class;

  constructor(name, Class) { // On donne la TOdo à la CLass
    this.#Class = Class;
    this.name = name;
  }

  getItems() { 
    return this.#list;
  }

  addItem(args) {
    const todo = new this.#Class(args);
    this.#list.push(todo);
  }

  deleteItem(item) {

  }
    // Permet de sauvegarder des éléments avant le reset // LocalStorage
  save() {

  }// Apelle le save si refresh de la page de la todo list
  init() {

  }
}

// le service en charge de la gestion de ma Liste de Todos , Apelle les méthodes de la class List // Event que dans cette class TodoService  (2 méthodes)
class TodoService {

  constructor(name,Class,listEl){
  this.list=new List(name,Class);
  this.listEl=listEl;
  }

  addItem(str) {
    const listOfItems=this.list.getItems();
    this.list.addItem();
    const div = document.createElement("div");
    div.innerText = str[0].toUpperCase();
    div.classList.add('todo');
    listEl.append(div);
    div.addEventListener('click', e => {
      
    })
    // Met à jour la liste => List.addItems
    //Met à jour l'élément
  }
}